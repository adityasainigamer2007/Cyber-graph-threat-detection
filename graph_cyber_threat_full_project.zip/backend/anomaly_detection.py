
import pandas as pd
from sklearn.ensemble import IsolationForest

def detect_anomalies():
    data = pd.read_csv('../datasets/network_logs.csv')

    model = IsolationForest(contamination=0.1)
    model.fit(data)

    data["anomaly"] = model.predict(data)

    result = data[data["anomaly"] == -1]

    return result.to_dict(orient="records")
