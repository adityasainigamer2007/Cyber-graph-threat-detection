
from flask import Flask, jsonify
from anomaly_detection import detect_anomalies

app = Flask(__name__)

@app.route('/')
def home():
    return {"message":"Cyber Graph Threat Detection API Running"}

@app.route('/detect')
def detect():
    anomalies = detect_anomalies()
    return jsonify(anomalies)

if __name__ == '__main__':
    app.run(debug=True)
