
from neo4j import GraphDatabase

URI = "bolt://localhost:7687"
AUTH = ("neo4j","password")

driver = GraphDatabase.driver(URI, auth=AUTH)

def create_user_device(user, device):
    with driver.session() as session:
        session.run(
        "MERGE (u:User {name:$user}) "
        "MERGE (d:Device {name:$device}) "
        "MERGE (u)-[:LOGIN]->(d)",
        user=user,
        device=device
        )
