
CREATE (u:User {name:'Employee1'})
CREATE (d:Device {name:'Laptop1'})
CREATE (s:Server {name:'InternalServer'})

CREATE (u)-[:LOGIN]->(d)
CREATE (d)-[:CONNECTS]->(s)
