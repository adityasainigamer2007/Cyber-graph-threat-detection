
import React, {useEffect, useState} from 'react';
import axios from 'axios';

function Dashboard(){

const [alerts,setAlerts] = useState([]);

useEffect(()=>{
 axios.get("http://127.0.0.1:5000/detect")
 .then(res=>{
 setAlerts(res.data)
 })
},[])

return(
<div>

<h2>Detected Threats</h2>

<ul>
{alerts.map((item,index)=>(
<li key={index}>
Login Attempts: {item.login_attempts} |
Data Transfer: {item.data_transfer}
</li>
))}

</ul>

</div>
)
}

export default Dashboard;
