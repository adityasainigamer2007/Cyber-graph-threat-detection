
import React from 'react';
import Dashboard from './components/Dashboard';

function App() {
 return (
  <div>
   <h1>Cyber Threat Detection Dashboard</h1>
   <Dashboard/>
  </div>
 );
}

export default App;
