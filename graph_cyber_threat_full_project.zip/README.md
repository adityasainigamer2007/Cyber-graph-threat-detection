
# AI Powered Cyber Threat Detection using Graph Databases

Hackathon project demonstrating cyber threat detection using graph relationships and anomaly detection.

## Features
- Graph based network relationship modeling
- AI anomaly detection using Isolation Forest
- Neo4j graph database
- React dashboard visualization
- Alert detection system

## Architecture
User Logs → Backend API → Neo4j Graph → AI Detection → Dashboard Visualization

## Run Backend
cd backend
pip install -r requirements.txt
python app.py

## Run Frontend
cd frontend
npm install
npm start
